#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include "MessageHandler.h"
#include "Singleton.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);
#ifdef Q_OS_ANDROID

    int fontId = QFontDatabase::addApplicationFont(":/Language/DroidSansFallback.ttf");
    //将字体Id传给applicationFontFamilies,得到一个QStringList,其中的第一个元素为新添加字体的family
    QString androidFont = QFontDatabase::applicationFontFamilies(fontId).at(0);
    QFont font(androidFont);
    QGuiApplication::setFont(font);
    // 时间:2018-05-07 15:36:04
    // 由于存在Android系统上会提示LocalStorage: can't create path /QML/OfflineStorage/Databases
    // 因此需要重新设定离线存储位置。
    // Default to"/data/data/com.qtdream.app/files/QML/OfflineStorage"
    // Will alter to "/storage/emulated/0/Android/data/com.wem.yym/files/offlineStorage"

    QDir dir;
    dir.mkdir("/storage/emulated/0/Android/data/com.wem.yym/files/offlineStorage");
    engine.setOfflineStoragePath("/storage/emulated/0/Android/data/com.wem.yym/files/offlineStorage" );

#endif

#ifdef QT_NO_DEBUG
    //注册日志系统
    Singleton<MessageHandler>::Instance(nullptr);
#endif

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
