#include "ServerInterFace.h"
#include "NetworkRequest.h"

ServerInterFace::ServerInterFace(QObject *parent) : QObject(parent),
  m_Reply_(nullptr),
  m_token_("")
{
}

void ServerInterFace::stopGetPost()
{
    m_Reply_->abort();
    m_Reply_->deleteLater();
    m_Reply_ = nullptr;
}

void ServerInterFace::loginRequest(QString username, QString passwd)
{
    NetworkRequest network;

    m_token_ = "";
    network.addKeyValue("userName", username);
    network.addKeyValue("password", passwd);

    doGetPost(network,API_LOGIN);

}

void ServerInterFace::logoutRequest(QString userId)
{
    NetworkRequest network;

    doGetPost(network,API_LOGOUT+userId,true);
}

void ServerInterFace::scanOrderNum(QString order)
{
    NetworkRequest network;

    network.addKeyValue("str", order);

    doGetPost(network,API_SCANORDER);
}

void ServerInterFace::setRequestHeadToken(QByteArray token)
{
    m_token_ = token;
}

void ServerInterFace::doGetPost(NetworkRequest &network,QString targeturl,bool isGet)
{
    Q_ASSERT(m_Reply_ == nullptr);
    //如果token非空就设置调用头数据token参数
    network.setHeadData(m_token_);

    if(isGet)
    {
        qInfo()<<"进来get";
        m_Reply_ = network.doGetRequest(targeturl);
    }
    else
    {
        qInfo()<<"进来post";
        m_Reply_ = network.doPostRequest(targeturl);
    }

     QReplyTimeout *pTimeout = new QReplyTimeout(m_Reply_, 5000);

     connect(m_Reply_,&QNetworkReply::finished,this, &ServerInterFace::onFinishSlot);
     connect(m_Reply_,SIGNAL(error(QNetworkReply::NetworkError)),this,SLOT(error()));
     connect(pTimeout,&QReplyTimeout::timeout,[=](){
         //发送连接超时信号，qml接收做提示处理
         emit sigTimeOut();
     });
//     connect(m_Reply_,&QNetworkReply::error,this, &ServerInterFace::error);
//     connect(m_Reply_, );
}

void ServerInterFace::onFinishSlot()
{
   QByteArray data = m_Reply_->readAll();
   qInfo()<<"获取到的data"<<data;

   if(!data.isEmpty())
   {
       QJsonDocument jsonDocument = QJsonDocument::fromJson(data);
       QJsonObject jsonObejct = jsonDocument.object();
       sigFinishJson(jsonObejct);
   }

   m_Reply_->deleteLater();
   m_Reply_ = nullptr;
}

void ServerInterFace::error(/*QNetworkReply::NetworkError code*/)
{
    qInfo()<<m_Reply_->errorString();
}
