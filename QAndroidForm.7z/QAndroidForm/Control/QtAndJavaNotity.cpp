#include "QtAndJavaNotity.h"
#include "simpleCustomEvent.h"
#include <QCoreApplication>
#include "QENUM.h"
QObject *g_listener_ = 0;

QtAndJavaNotity::QtAndJavaNotity(QObject *parent) : QObject(parent),
    m_NetworkMager_(nullptr),
    m_scanEnabled_(false)
{
    SimpleCustomEvent::eventType();
    g_listener_ = qobject_cast<QObject*>(this);

    registerNativeMethods();

    m_NetworkMager_ = new QNetworkConfigurationManager(this);

    connect(m_NetworkMager_, &QNetworkConfigurationManager::onlineStateChanged, this, [this](bool is_online){
           this->sigNetWorkStateChanged(is_online);
    });
}



bool QtAndJavaNotity::registerNativeMethods()
{
    qInfo()<<"进来注册信息";
    //下面的方法都是再java中有申明的，实现由C++实现
    JNINativeMethod methods[] {
        {"onNotifyState", "(I)V", (void*)onJavaNotify},
        {"onInforNotify", "(Ljava/lang/String;I)V", (void *)onJavaApplyNotify},
    };

    const char *classname = "com/notityPort/QtNativeNotify";
    jclass clazz;
    QAndroidJniEnvironment env;

    QAndroidJniObject javaClass(classname);
    clazz = env->GetObjectClass(javaClass.object<jobject>());
    qDebug() << "find ExtendsQtNative - " << clazz;
    bool result = false;
    if(clazz)
    {
        jint ret = env->RegisterNatives(clazz,
                                        methods,
                                        sizeof(methods) / sizeof(methods[0]));
        env->DeleteLocalRef(clazz);
        qDebug() << "RegisterNatives return - " << ret;
        result = ret >= 0;
    }
    if(env->ExceptionCheck())
    {
        env->ExceptionClear();
    }
    return result;
}

void QtAndJavaNotity::showHintInfo(QString info)
{
    QAndroidJniObject infoObject = QAndroidJniObject::fromString(info);
    QAndroidJniObject::callStaticMethod<void>(
                                        "com/main/MainActivity",
                                        "showTooltip",
                                        "(Ljava/lang/String;)V",
                                        infoObject.object<jstring>()
                );
}

void QtAndJavaNotity::backExit()
{
    qInfo()<<"进来exit";
    QAndroidJniObject::callStaticMethod<void>(
                                        "com/main/MainActivity",
                                        "exit"
                );
}

void QtAndJavaNotity::playMedia(int speedType)
{
    QStringList playList;
    playList<<":/Audio/SaoMaChengGuo-low.wav"<<":/Audio/SaoMaChengGuo-Nomal.wav"
           <<":/Audio/SaoMiaoChengGuo-low.wav"<<":/Audio/SaoMiaoChengGuo-Nomal.wav";

    QSound::play(playList[speedType]);
}


void QtAndJavaNotity:: onJavaNotify(JNIEnv *env, jobject thiz, jint result)
{
    Q_UNUSED(env)
    Q_UNUSED(thiz)

    qInfo()<<"java通知过来---------"<<result;
    QString qstrData;
    int  notify = result;

    QCoreApplication::postEvent(g_listener_, new SimpleCustomEvent(notify, qstrData));
}
void QtAndJavaNotity::onJavaApplyNotify(JNIEnv *env, jobject thiz, jstring result, jint code)
{
    Q_UNUSED(env)
    Q_UNUSED(thiz)
    qInfo()<<"获取到java信息进来----"<<code;
    QString qstrData = "";

    const char *nativeString = env->GetStringUTFChars(result, 0);
    qstrData = nativeString;
    env->ReleaseStringUTFChars(result, nativeString);
//    qDebug()<<"获取到的微信信息02qstrData --------- == "<<qstrData;
    int notify = code;

    QCoreApplication::postEvent(g_listener_, new SimpleCustomEvent(notify, qstrData));
}

bool QtAndJavaNotity::event(QEvent *e)
{
    if(e->type() == SimpleCustomEvent::eventType())
    {
        e->accept();

        SimpleCustomEvent *sce = (SimpleCustomEvent*)e;

        switch(sce->m_arg1)
        {
            case 4:
                backBtn();
            break;
        }
    }

    return QObject::event(e);
}
