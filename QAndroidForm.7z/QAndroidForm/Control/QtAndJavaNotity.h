#ifndef QTANDJAVANOTITY_H
#define QTANDJAVANOTITY_H

#include <QObject>
#include <QNetworkConfigurationManager>
#include <QDebug>
#include <QNetworkReply>
#ifdef Q_OS_ANDROID
#include <QAndroidJniEnvironment>
#include <QAndroidJniObject>
#include <QtAndroid>
#include <QThread>
#include <QSound>
#include <QTextCodec>
#endif

class QENUM;
class QtAndJavaNotity : public QObject
{
    Q_OBJECT
public:
    explicit QtAndJavaNotity(QObject *parent = nullptr);

    enum JavaNotitfType{
        ScanNotitf = 3
    };

    inline void judgeNetwork()
    {
        Q_ASSERT(m_NetworkMager_ != nullptr);

        if(m_NetworkMager_ == nullptr) {
            qFatal("m_NetworkMager_ is nullptr");
            return;
        }

        if(!m_NetworkMager_->isOnline())
        {
            this->sigNetWorkStateChanged(false);
        }
        else
        {
            this->sigNetWorkStateChanged(true);
        }
    }


     bool registerNativeMethods();
     //信息提示框
     Q_INVOKABLE void showHintInfo(QString info);

     //再按一次推出
     Q_INVOKABLE void backExit();
     //播放声音 speedType -- 0代表扫码low，1代表扫码Nomal
     Q_INVOKABLE void playMedia(int speedType = 1);

protected:

#ifdef Q_OS_ANDROID

     bool event(QEvent *e);
     static void onJavaNotify(JNIEnv *env, jobject thiz, jint result);
     static void onJavaApplyNotify(JNIEnv *env, jobject thiz, jstring result, jint code);

#endif

signals:
    void sigNetWorkStateChanged(bool state);
    void backBtn();
public slots:

private:
     QNetworkConfigurationManager * m_NetworkMager_;
     bool m_scanEnabled_;
};

#endif // QTANDJAVANOTITY_H
