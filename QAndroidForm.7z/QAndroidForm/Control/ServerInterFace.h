#ifndef SERVERINTERFACE_H
#define SERVERINTERFACE_H

#include <QObject>

#define TEST

#ifdef TEST
#define TestAPI "http://192.168.1.158:8080/EasyAntPulse/"
#else
#define API ""
#endif

//登陆
#define API_LOGIN TestAPI "login"

//登出
#define API_LOGOUT TestAPI "admin/user/logout?operatorUserId="

//扫描提货单
#define API_SCANORDER TestAPI "/factory/shipping/order"

#include <QNetworkAccessManager>
#include <QDebug>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QReplyTimeout.h>

class NetworkRequest;
class ServerInterFace : public QObject
{
    Q_OBJECT
public:
    explicit ServerInterFace(QObject *parent = nullptr);

    Q_INVOKABLE void stopGetPost();

    //用户登录接口
    Q_INVOKABLE void loginRequest(QString username,QString passwd);
    //用户注销登出接口
    Q_INVOKABLE void logoutRequest(QString userId);
    //用户提交出货单(扫描提货单)
    Q_INVOKABLE void scanOrderNum(QString order);

    //设置请求的头数据token，在登录成功后会自动调用
    Q_INVOKABLE void setRequestHeadToken(QByteArray token);

    //isGet是否是get请求,false是post，true是get请求
    void doGetPost(NetworkRequest&network,QString targeturl,bool isGet = false);

signals:
    void sigFinishJson(QJsonObject json);
    void sigTimeOut();
public slots:
    void onFinishSlot();
    void error(/*QNetworkReply::NetworkError*/);
private:

    QNetworkReply * m_Reply_;
    QByteArray m_token_;
};

#endif // SERVERINTERFACE_H
