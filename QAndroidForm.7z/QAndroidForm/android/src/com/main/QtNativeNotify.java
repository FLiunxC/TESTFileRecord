package com.notityPort;

import java.lang.String;

public class QtNativeNotify
{
    public static int count = 0;

    public static void JavaNotify(int stateType)
    {
        onNotifyState(stateType);
    }

    public static void InforNotify(String infor, int code)
    {
        onInforNotify(infor, code);
    }

    //通知枚举
    public static final int scanNotitf = 3;
    public static final int backBtn = 4;

    //本地方法
    private static native void onNotifyState(int stateType);
    private static native void onInforNotify(String infor, int code);
}
