package com.main;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.app.Activity;
import android.view.KeyEvent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.widget.Toast;
import android.content.Intent;
import org.qtproject.qt5.android.bindings.QtActivity;
import com.notityPort.QtNativeNotify;
import qt.slide.app.R;

public class MainActivity extends org.qtproject.qt5.android.bindings.QtActivity{

     private final int SPLASH_DISPLAY_LENGHT = 3000;  //延迟3秒

     public static Context sContext;
     //定义一个变量，来标识是否退出
        private static boolean isExit = false;

        public static Handler mHandler = new Handler() {

            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                isExit = false;
            }
        };

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
                    sContext = getApplicationContext();
              }

        @Override
        public boolean onKeyDown(int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {

                if(isExit)
                {
                    finish();
                    System.exit(0);
                }
                QtNativeNotify.JavaNotify(QtNativeNotify.backBtn);

                return false;
            }
            return super.onKeyDown(keyCode, event);
        }

        public static void exit(){
            if (!isExit) {
                isExit = true;
               showTooltip("再按一次退出");
//                Toast.makeText(getApplicationContext(), "再按一次退出程序",
//                        Toast.LENGTH_SHORT).show();
                // 利用handler延迟发送更改状态信息
                mHandler.sendEmptyMessageDelayed(0, 2000);
            }
        }

    /**启动java新线程执行功能*/
    private static Handler m_handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case 0:
                Toast.makeText(sContext,msg.obj.toString(),Toast.LENGTH_SHORT).show();

                break;


            };
        }
    };
    /***Toast提示框***/
    public static void showTooltip(String info)
    {
        Message msg = new Message();
        msg.what = 0;
        msg.obj = info;
        m_handler.sendMessage(msg);
    }


}
